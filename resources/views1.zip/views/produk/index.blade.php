@extends('layouts.admin')
@section('content')
<div class="container">
    <h3 class="mt-3 align-content-center">Data Produk</h3>
    <a href="{{url('produk/create')}}" class="btn btn-success mb-3">Tambah Data</a>

    @if (session()->get('success'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>{{ session()->get('success') }}</strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    @endif

    {{-- <div class="row">
        <div class="col-md-12">
            <table id="produk" class="table table table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nama Barang</th>
                        <th>Stok Barang</th>
                        <th>Harga Barang</th>
                        <th colspan="2">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($produk as $produk)
                    <tr>
                        <td>{{$produk->id}}</td>
                        <td>{{$produk->nama_barang}}</td>
                        <td>{{$produk->stok_barang}}</td>
                        <td>{{$produk->harga_barang}}</td>
                        <td><a class="btn btn-primary" href="{{ url("/produk/{$produk->id}/edit") }}">Edit</a></td>
                        <td>
                        <form action="{{ url("produk/{$produk->id}") }}" method="post">
                            @csrf
                            @method('DELETE')
                            <button class="btn btn-warning">Hapus</button>
                            </form>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div> --}}
    <div class="box-body table-responsive">
      <table id="produk" class="table table-bordered table-hover">
        <thead>
          <tr>
            <th>ID</th>
            <th>Nama Barang</th>
            <th>Stok Barang</th>
            <th>Harga Barang</th>
            <th colspan="2">Aksi</th>
          </tr>
        </thead>
        <tbody>
            @foreach($produk as $produk)
                <tr>
                    <td>{{$produk->id}}</td>
                    <td>{{$produk->nama_barang}}</td>
                    <td>{{$produk->stok_barang}}</td>
                    <td>{{$produk->harga_barang}}</td>
                    <td><a class="btn btn-primary" href="{{ url("/produk/{$produk->id}/edit") }}">Edit</a></td>
                    <td>
                    <form action="{{ url("produk/{$produk->id}") }}" method="post">
                        @csrf
                        @method('DELETE')
                        <button class="btn btn-warning">Hapus</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
      </table>
    </div>
</div>
@endsection
<!-- Javascript Datatable -->
<script type="text/javascript">
  $(document).ready(function() {
    $('#produk').DataTable();
  });
</script>
